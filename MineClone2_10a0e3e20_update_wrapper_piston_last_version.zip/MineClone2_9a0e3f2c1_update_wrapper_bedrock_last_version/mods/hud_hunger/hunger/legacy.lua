hud.item_eat = hunger.item_eat
hud.set_hunger = hunger.save
hud.get_hunger = hunger.load
hud.save_hunger = hunger.save
hud.load_hunger = hunger.load