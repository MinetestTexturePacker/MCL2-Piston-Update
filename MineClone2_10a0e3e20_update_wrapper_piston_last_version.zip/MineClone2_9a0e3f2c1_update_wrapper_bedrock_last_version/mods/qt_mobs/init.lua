-- qt_mobs
--this mod was mostly copied from Plzadam's mobs mod, with some changes to the api from Blockmen's creatures mod(knockback and damaging tools)

dofile(minetest.get_modpath("qt_mobs").."/api.lua")
dofile(minetest.get_modpath("qt_mobs").."/overworld.lua")