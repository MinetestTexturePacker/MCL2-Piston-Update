

dungeon_chests = {}


local modpath = minetest.get_modpath(minetest.get_current_modname())

dofile(modpath .. "/handlers/register.lua")
dofile(modpath .. "/mimic.lua")
dofile(modpath .. "/chests.lua")
dofile(modpath .. "/treasures.lua")
