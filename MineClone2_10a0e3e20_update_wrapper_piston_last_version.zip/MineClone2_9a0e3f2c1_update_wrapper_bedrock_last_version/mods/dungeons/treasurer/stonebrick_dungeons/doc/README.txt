
	STONEBRICK DUNGEONS MODULE
	==========================

	Turns cobblestone dungeons into stonebrick.

	Version: 0.2.2
	Source code's license: GPLv3

	Dependencies: default, stairs (found in Minetest Game)
	Supported: castle_masonry

	Report bugs or request help on the forum topic:
	https://forum.minetest.net/viewtopic.php?f=9&t=18457


	Installation
	============

	Unzip the archive, place the folder in
	../minetest/mods/

	If you only want this to be used in a single world, place it in
	../minetest/worlds/WORLD_NAME/worldmods/

	GNU+Linux - If you use a system-wide installation place it in
	~/.minetest/mods/

	For further information or help see:
	https://wiki.minetest.net/Help:Installing_Mods
